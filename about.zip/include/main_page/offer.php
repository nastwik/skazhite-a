                  <section class="slider-area relative overflow-hidden pb-0" data-bgimage="url(/images/background/1.webp) center">
                        <div class="container relative z-1000">
                           <div class="row g-4 align-items-center justify-content-between">
                              <div class="col-lg-6 offer_content">
                                    <div class="relative z-1000">
                                       <div class="header-title wow fadeInUp" data-wow-delay=".0s">Прием <span class="text-blue">отоларинголога</span><br>высшей категории</div>

                                       <p class="wow fadeInUp" data-wow-delay=".2s">Запишитесь удобным способом — по телефону или через форму онлайн-записи</p>

                                       <div class="spacer-10"></div>

                                       <div class="team_butns">
                                          <a href="tel:+78632049558" class="btn-main btn-red wow fadeInUp" data-wow-delay=".4s" href="book-service.html">+7 (863) 204-95-58</a>
                                          <a href="" class="btn-main btn-blue wow fadeInUp" data-wow-delay=".4s" href="book-service.html">На новую МИС</a>
                                       </div>

                                       <div class=""></div>

                                       <div class="spacer-double"></div>
                                    </div>
                              </div>

                              <div class="col-lg-6">
                                    <img src="/images/doctors/olga.png" class="w-100 wow fadeInUp" data-wow-delay=".6s" alt="">
                              </div>

                           </div>
                        </div>
                  </section>