            <section class="bg-blue">
                <div class="container">
                    <div class="row g-4">
                        <div class="col-lg-6 offset-lg-3 text-center">
                            <div class="subtitle wow fadeInUp mb-3">Галерея</div>
                            <div class="section-title wow fadeInUp" data-wow-delay=".2s">Фото клиники</div>
                            <div class="spacer-single"></div>
                        </div>
                    </div>
                        <div class="row">
                            <p class="imglist">
                                <a href="images/background/plug.png" data-fancybox="images" class="soft-shadow">
                                    <img src="images/background/mini-370x260.png">
                                </a>
                                
                                <a href="images/background/plug.png" data-fancybox="images" class="soft-shadow">
                                    <img src="images/background/mini-370x260.png">
                                </a>
                                
                                <a href="images/background/plug.png" data-fancybox="images" class="soft-shadow">
                                    <img src="images/background/mini-370x260.png">
                                </a>
                                
                                <a href="images/background/plug.png" data-fancybox="images" class="soft-shadow">
                                    <img src="images/background/mini-370x260.png">
                                </a>
                                
                                <a href="images/background/plug.png" data-fancybox="images" class="soft-shadow">
                                    <img src="images/background/mini-370x260.png">
                                </a>

                                <a href="images/background/plug.png" data-fancybox="images" class="soft-shadow">
                                    <img src="images/background/mini-370x260.png">
                                </a>
                            </p>
                        </div>
                </div>
            </section>