<? require_once 'header.php' ?>

   <? require_once 'include/main_page/offer.php' ?>

   <? require_once 'include/main_page/services.php' ?>

   <? require_once 'include/main_page/advantages.php' ?>

   <? require_once 'include/main_page/doctors.php' ?>

   <? require_once 'include/main_page/about.php' ?>

   <? require_once 'include/main_page/lidmagnit.php' ?>

   <? require_once 'include/main_page/gallery.php' ?>

   <? require_once 'include/main_page/reviews.php' ?>

   <? require_once 'include/main_page/contacts.php' ?>

<? require_once 'footer.php' ?>